## 0.0.2
- fix for adding the `breakerbox` command to the terminal

## 0.0.1
- initial release