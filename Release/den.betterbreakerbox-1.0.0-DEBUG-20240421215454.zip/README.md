# Meltdown Chance

Description goes here


## [Changelog](https://thunderstore.io/c/lethal-company/p/den/BetterBreakerBox/changelog/)

### 1.0.0
- initial release