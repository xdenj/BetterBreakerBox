## 0.0.4
- fixed pulling of the Apparatus not turning off the power to the facility
- added disabling the Breaker Box after Apparatus is pulled

## 0.0.3
- added sticky note to breaker box

## 0.0.2
- fix for adding the `breakerbox` command to the terminal
- fix for timer decrements
- added hint aboout switch positions to breakerbox command

## 0.0.1
- initial release